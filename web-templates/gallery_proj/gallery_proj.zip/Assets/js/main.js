$(document).ready(function () {
    $(".close").click(function(){
        $(".modal").hide();
      });

    var elm_class = ".jsearch";
    var isfull = false;
    $(window).scroll(function () {
		if ($(this).scrollTop() > 140 && isfull == false) {
            $(elm_class).animate({width: '80%'});
            isfull = true;
		} else if($(this).scrollTop() <= 140 && isfull == true) {
            $(elm_class).animate({width: '60%'});
            isfull = false;
		};
	});
});

// When the user clicks on <span> (x), close the modal
